// Create a new color picker instance
// https://iro.js.org/guide.html#getting-started
const colorPicker = new iro.ColorPicker(".colorPicker", {
  // color picker options
  // Option guide: https://iro.js.org/guide.html#color-picker-options
  width: 260,
  layout: [
  // default slider, will reflect whichever color is currently active
  {
    component: iro.ui.Wheel,
    options: {
      borderColor: '#ffffff',
      wheelAngle: 90 } }],



  // Pure red, green and blue
  colors: [
  "hsl(0, 100%, 50%)",
  "hsl(180, 100%, 50%)"],

  handleRadius: 10,
  borderWidth: 5 });


const colorList = document.getElementById("colorList");
const activeColor = document.getElementById("activeColor");

// function setColor(colorIndex) {
//   // setActiveColor expects the color index!
//   colorPicker.setActiveColor(colorIndex);
// }

// https://iro.js.org/guide.html#color-picker-events
colorPicker.on(["mount", "color:change"], function () {

  colorPicker.setActiveColor(0);
  // deklarasi variable datahex untuk mengambil data hexadecimal warna
  datahex = colorPicker.colors[0].hexString;
  // melakukan pengecekan data hexadecimal warna jika memiliki simbol # maka hapus tanda # e.g : #f0f0f0 -> f0f0f0
  if (datahex.indexOf('#') === 0) {
    datahex = datahex.slice(1);
  }

  // kemudian kita deklarasikan lagi variable red,green,blue untuk konversi hex ke rgb lalu kita kurangi 255 karna ini ada complement
  // fungsi datahex.slice(x,y) berguna untuk menampilkan sebagian data saja berdasarkan index array pada suatu data yang terdapat pada suatu variable
  // parseInt(someData,16), berfungsi untuk merubah nilai hex ke decimal lalu di ikuti dengan fungsi tambahan toString(16) berguna untuk merubah kembali bilangan decimal ke bilangan hex

  var r = red = parseInt(datahex.slice(0, 2), 16),
  g = green = parseInt(datahex.slice(2, 4), 16),
  b = blue = parseInt(datahex.slice(4, 6), 16);

  //   Konversi RGB KE HSL
  r /= 255;
  g /= 255;
  b /= 255;
  const l = Math.max(r, g, b);
  const s = l - Math.min(r, g, b);
  const h = s ?
  l === r ?
  (g - b) / s :
  l === g ?
  2 + (b - r) / s :
  4 + (r - g) / s :
  0;
  const hue0 = Math.round(60 * h < 0 ? 60 * h + 360 : 60 * h);
  const sat0 = Math.round(100 * (s ? l <= 0.5 ? s / (2 * l - s) : s / (2 - (2 * l - s)) : 0));
  const lig0 = Math.round(100 * (2 * l - s) / 2);
  const dcomp = (hue0 + 180) % 360;
  // const dataHsl = "hsl("+hue0+", "+sat0+"%, "+lig0+"%)";
  // const dataHslComp = "hsl("+dcomp+", "+sat0+"%, "+lig0+"%)";

  var dh = hue0,ds = sat0,dl = lig0;

  ds /= 100;
  dl /= 100;
  const k = n => (n + dh / 30) % 12;
  const a = ds * Math.min(dl, 1 - dl);
  const f = (n) =>
  dl - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  const dred = Math.round(255 * f(0));
  const dgreen = Math.round(255 * f(8));
  const dblue = Math.round(255 * f(4));

  colorList.innerHTML = '';
  colorPicker.colors[0].hsl = { h: hue0, s: sat0, l: lig0 };
  const hslString0 = colorPicker.colors[0].hslString;
  colorPicker.colors[1].hsl = { h: dcomp, s: sat0, l: lig0 };
  const hslString1 = colorPicker.colors[1].hslString;
  colorList.innerHTML += `
      <li onClick="setColor(0)">
        <div class="swatch" style="background: ${hslString0}"></div>
        <span>0: ${hslString0}</span>
      </li>
      <li onClick="setColor(1)">
        <div class="swatch" style="background: ${hslString1}"></div>
        <span>1: ${hslString1}</span>
      </li>
    `;
});

colorPicker.on(["mount", "color:setActive", "color:change"], function () {
  // colorPicker.color is always the active color
  const index = colorPicker.colors[0].index;
  const rgbString = colorPicker.colors[0].rgbString;
  activeColor.innerHTML = `
    <div class="swatch" style="background: ${rgbString}"></div>
    <span>${index}: ${rgbString}</span>
  `;
});