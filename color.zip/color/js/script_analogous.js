// Create a new color picker instance
// https://iro.js.org/guide.html#getting-started
const colorPicker = new iro.ColorPicker(".colorPicker", {
  // color picker options
  // Option guide: https://iro.js.org/guide.html#color-picker-options
  width: 260,
  layout: [
  // default slider, will reflect whichever color is currently active
  {
    component: iro.ui.Wheel,
    options: {
      borderColor: '#ffffff',
      wheelAngle: 90 } }],



  // Pure red, green and blue
  colors: [
  "hsl(0, 100%, 50%)",
  "hsl(30, 100%, 50%)",
  "hsl(330, 100%, 50%)"],

  handleRadius: 10,
  borderWidth: 5 });


const colorList = document.getElementById("colorList");
const activeColor = document.getElementById("activeColor");

// function setColor(colorIndex) {
//   // setActiveColor expects the color index!
//   colorPicker.setActiveColor(colorIndex);
// }

// https://iro.js.org/guide.html#color-picker-events
colorPicker.on(["mount", "color:change"], function () {

  colorPicker.setActiveColor(0);
  // deklarasi variable datahex untuk mengambil data hexadecimal warna
  datahex = colorPicker.colors[0].hexString;
  // melakukan pengecekan data hexadecimal warna jika memiliki simbol # maka hapus tanda # e.g : #f0f0f0 -> f0f0f0
  if (datahex.indexOf('#') === 0) {
    datahex = datahex.slice(1);
  }

  // kemudian kita deklarasikan lagi variable red,green,blue untuk konversi hex ke rgb lalu kita kurangi 255 karna ini ada complement
  // fungsi datahex.slice(x,y) berguna untuk menampilkan sebagian data saja berdasarkan index array pada suatu data yang terdapat pada suatu variable
  // parseInt(someData,16), berfungsi untuk merubah nilai hex ke decimal lalu di ikuti dengan fungsi tambahan toString(16) berguna untuk merubah kembali bilangan decimal ke bilangan hex

  var r = red = parseInt(datahex.slice(0, 2), 16),
  g = green = parseInt(datahex.slice(2, 4), 16),
  b = blue = parseInt(datahex.slice(4, 6), 16);

  //   Konversi RGB KE HSL
  r /= 255;
  g /= 255;
  b /= 255;
  const l = Math.max(r, g, b);
  const s = l - Math.min(r, g, b);
  const h = s ?
  l === r ?
  (g - b) / s :
  l === g ?
  2 + (b - r) / s :
  4 + (r - g) / s :
  0;
  const hue0 = Math.round(60 * h < 0 ? 60 * h + 360 : 60 * h);
  const sat0 = Math.round(100 * (s ? l <= 0.5 ? s / (2 * l - s) : s / (2 - (2 * l - s)) : 0));
  const lig0 = Math.round(100 * (2 * l - s) / 2);
  const dAna0 = (hue0 + 30) % 360;
  const dAna1 = (hue0 + 330) % 360;
  // const dataHsl = "hsl("+hue0+", "+sat0+"%, "+lig0+"%)";
  // const dataHslAna0 = "hsl("+dAna0+", "+sat0+"%, "+lig0+"%)";
  // const dataHslAna1 = "hsl("+dAna1+", "+sat0+"%, "+lig0+"%)";
  // const dataHslAna2 = "hsl("+dAna1+", "+sat0+"%, "+lig0+"%)";

  colorList.innerHTML = '';
  colorPicker.colors[0].hsl = { h: hue0, s: sat0, l: lig0 };
  const colString0 = colorPicker.colors[0].hexString;
  colorPicker.colors[1].hsl = { h: dAna0, s: sat0, l: lig0 };
  const colString1 = colorPicker.colors[1].hexString;
  colorPicker.colors[2].hsl = { h: dAna1, s: sat0, l: lig0 };
  const colString2 = colorPicker.colors[2].hexString;
  colorList.innerHTML += `
      <li onClick="setColor(1)">
        <div class="swatch" style="background: ${colString1}"></div>
        <span>1: ${colString1}</span>
      </li>
      <li onClick="setColor(0)">
        <div class="swatch" style="background: ${colString0}"></div>
        <span>0: ${colString0}</span>
      </li>
      <li onClick="setColor(2)">
        <div class="swatch" style="background: ${colString2}"></div>
        <span>2: ${colString2}</span>
      </li>
    `;
});

colorPicker.on(["mount", "color:setActive", "color:change"], function () {
  // colorPicker.color is always the active color
  const index = colorPicker.colors[0].index;
  const colString = colorPicker.colors[0].hexString;
  activeColor.innerHTML = `
    <div class="swatch" style="background: ${colString}"></div>
    <span>${index}: ${colString}</span>
  `;
});