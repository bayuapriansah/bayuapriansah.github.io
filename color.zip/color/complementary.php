
          <div class="wrap">
            <div class="half">
              <div class="colorPicker"></div>
            </div>
            <div class="half">
              <span>Complement Colors:</span>
              <ul id="colorList"></ul>
              <span>Active Color:</span>
              <div id="activeColor"></div>
            </div>
          </div>
          <div class="container" style="max-width: 80%;">
          <div class="form-group">
            <label>Pilih Color Wheel</label>
            <select class="form-control" onchange="location = this.value;">
                <option value="https://color.loxa.tech/index.php?color=complement">Color Wheel Complementary</option>
                <option value="https://color.loxa.tech/index.php?color=triadic">Color Wheel Triadic</option>
                <option value="https://color.loxa.tech/index.php?color=analogous">Color Wheel Analagous</option>>
                <option value="https://color.loxa.tech/index.php?color=table">Table Color Harmony</option>
            </select>
          </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <p>© Color Wheel 2022</p>
      </footer>
    </div>
  </div>
  <!-- /container -->
  <!-- partial -->
  <script src='https://cdn.jsdelivr.net/npm/@jaames/iro@beta/dist/iro.min.js'></script>
  <script src="js/script_complement.js"></script>
</body>
</html>