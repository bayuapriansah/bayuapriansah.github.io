<?php
    if ($_GET['color'] == 'complement') {
        include('complementary.php');
    }elseif ($_GET['color'] == 'triadic') {
        include('triadic.php');
    }elseif ($_GET['color'] == 'analogous') {
        include('analogous.php');
    }elseif ($_GET['color'] == 'table') {
        include('color.php');
    }else{
?>
        <a style="color:white" href="<?php echo "http://" . $_SERVER['SERVER_NAME'] . $thisPath = dirname($_SERVER['PHP_SELF']); ?>/home.php?color=complement">Don't Do That, Click Here To Go Back</a>
<?php
    }
?>