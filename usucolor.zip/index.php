<?php
// header("Location : ".);
?>
<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="../../../../favicon.ico">
  <title>COLOR HARMONY</title>
  <meta http-equiv="refresh" content="0;url=<?php echo "http://" . $_SERVER['SERVER_NAME'] . $thisPath = dirname($_SERVER['PHP_SELF']); ?>/home.php?color=complement">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <!-- Custom styles for this template -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <?php
  if ($_GET['color'] == 'table') {
  ?>
    <style>
    #theform table {
    	
    }
    #theform td {
    	
    }
    
    h1, h2, h3 {
    	display:inline;
    	margin:0;
    	padding:0;
    }
    h2 {
    	font-size:14pt;
    }
    
    #header {
    	padding:12px 25px;
    	background-color:#139;
    }
    #header h1, #header h2 {
    	display:inline;
    	color:#fff;
    }
    #cwnav {
    	position:absolute;
    	top:-1px;
    	background-color:#139;
    	width:100%;
    }
    #cwnav>div:last-child { display:none; } 
    
    #navcontainer {
    	position:relative!important;
    	margin:0 auto;
    }
    
    #top {
    	position:relative;
    	text-align:center;
    	padding:8px 0;
    }
    
    #bottom {
    	position:relative;
    	text-align:center;
    	margin-top:15px;
    }
    
    #everything {
    	position:relative;
    }
    
    #cwmain { padding-top:12px; }
    #cwmain form {
    	display:inline;
    }
    
    #monochrome, #analogous, #complementary, #splitcomplementary, #triadic {
    	position:relative;
    	height:255px;
    	text-align:center;
    }
    
    #complementary { width:182px; }
    #splitcomplementary { width:274px; }
    #triadic { width:274px; }
    #analogous { width:274px; }
    
    .swatch {
    	position:absolute;
    	height:42px;
    	width:90px;
    	font-size:7pt;
    	text-align:center;
    	background:black;
    	color:transparent;
    }
    .swatch:hover {
    	color:#666;
    }
    
    .sa { top:30px; }
    .sb { top:74px; }
    .sc { top:118px; }
    .sd { top:162px; }
    .se { top:206px; }
    
    .s1 { left:0px; }
    .s2 { left:92px; }
    .s3 { left:184px; }
    
    #TriggerNoteStripeBottom>div:last-child { padding:0!important; }
    </style>
</head>
<body>
  <div class="jarak">
    <div class="container">
      <div class="header clearfix">
        <h3 class="text-muted">Color Wheel Harmony</h3>
      </div>
      <div class="jumbotron">
        <div class="container">
<?php
    include('nav.php');
    }else{
?>
</head>
<body>
  <div class="jarak">
    <div class="container">
      <div class="header clearfix">
        <h3 class="text-muted">Color Wheel Harmony</h3>
      </div>
      <div class="jumbotron">
        <div class="container">
<?php
    include('nav.php');
    }
?>
